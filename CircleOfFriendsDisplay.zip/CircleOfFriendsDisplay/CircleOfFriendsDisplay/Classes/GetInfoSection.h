//
//  GetInfoSection.h
//  CircleOfFriendsDisplay
//
//  Created by liyunxiang on 16/11/3.
//  Copyright © 2016年 李云祥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetInfoSection : NSObject
+ (NSMutableArray *)getInfo;
@end
