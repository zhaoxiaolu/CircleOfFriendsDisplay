//
//  DFReachabilityUtil.h
//  Heacha
//
//  Created by Allen Zhong on 15/2/13.
//  Copyright (c) 2015年 Datafans Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Reachability.h"

@interface DFReachabilityUtil : NSObject

+(BOOL) isNetworkAvailable;

@end
