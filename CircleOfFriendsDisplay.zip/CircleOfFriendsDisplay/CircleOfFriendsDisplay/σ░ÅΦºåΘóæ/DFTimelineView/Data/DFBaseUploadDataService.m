//
//  DFBaseUploadDataService.m
//  coder
//
//  Created by Allen Zhong on 15/5/22.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFBaseUploadDataService.h"

@implementation DFBaseUploadDataService


-(void)executeRequest
{
    
}


-(void) upload:(NSData *) data success:(RequestSuccess) success
{
    
}

-(NSString *)getFileType
{
    return @"";
}
@end
