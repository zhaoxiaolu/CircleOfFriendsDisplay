//
//  UILabel+Corner.h
//  coder
//
//  Created by Allen Zhong on 15/5/7.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Corner)

+(UILabel *) cornerLabel:(UIColor *) bgColor;

@end
