//
//  UILabel+Corner.m
//  coder
//
//  Created by Allen Zhong on 15/5/7.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "UILabel+Corner.h"

@implementation UILabel (Corner)

+(UILabel *) cornerLabel:(UIColor *) bgColor
{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    return label;
    
}
@end
