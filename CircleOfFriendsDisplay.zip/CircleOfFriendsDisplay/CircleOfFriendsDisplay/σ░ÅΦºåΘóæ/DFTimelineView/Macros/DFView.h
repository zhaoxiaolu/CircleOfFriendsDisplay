//
//  DFView.h
//  coder
//
//  Created by Allen Zhong on 15/5/7.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#ifndef coder_DFView_h
#define coder_DFView_h


#define BaseViewColor [UIColor whiteColor]
#define HudDefaultHideTime 1

#endif
