//
//  DFDevice.h
//  Heacha
//
//  Created by Allen Zhong on 15/2/12.
//  Copyright (c) 2015年 Datafans Inc. All rights reserved.
//

#ifndef Heacha_DFDevice_h
#define Heacha_DFDevice_h

#define ScreenWidth [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define SystemVersion [RRDevice systemVersionNumber]



#endif
