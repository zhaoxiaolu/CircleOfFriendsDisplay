//
//  DFTextImageLineCell.h
//  DFTimelineView
//
//  Created by Allen Zhong on 15/9/27.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFBaseLineCell.h"
#import "DFBaseLineItem.h"


@interface DFTextImageLineCell : DFBaseLineCell

@end
