//
//  Const.h
//  DFTimelineView
//
//  Created by Allen Zhong on 15/10/1.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#ifndef DFTimelineView_Const_h
#define DFTimelineView_Const_h

#define HighLightTextColor [UIColor colorWithRed:92/255.0 green:140/255.0 blue:193/255.0 alpha:1.0]


#endif
