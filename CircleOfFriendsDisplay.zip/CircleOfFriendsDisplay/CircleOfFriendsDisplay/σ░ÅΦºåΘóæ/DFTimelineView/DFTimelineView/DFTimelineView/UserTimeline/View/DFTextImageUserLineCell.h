//
//  DFTextImageUserLineCell.h
//  DFTimelineView
//
//  Created by Allen Zhong on 15/10/15.
//  Copyright (c) 2015年 Datafans, Inc. All rights reserved.
//

#import "DFBaseUserLineCell.h"
#import "DFTextImageUserLineItem.h"

@interface DFTextImageUserLineCell : DFBaseUserLineCell

@end
