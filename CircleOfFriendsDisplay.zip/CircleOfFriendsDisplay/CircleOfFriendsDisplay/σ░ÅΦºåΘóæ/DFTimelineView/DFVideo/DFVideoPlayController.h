//
//  DFVideoPlayController.h
//  MongoIM
//
//  Created by Allen Zhong on 16/2/14.
//  Copyright © 2016年 MongoIM. All rights reserved.
//
#import "DFBaseViewController.h"

@interface DFVideoPlayController : DFBaseViewController

-(instancetype)initWithFile:(NSString *) filePath;
@end
